package com.example.lowongan;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final List<Job> allJobs = new ArrayList<>();
    private final List<Job> shownJobs = new ArrayList<>();
    private JobAdapter adapter;
    private EditText searchInput;
    private Spinner categorySpinner;
    private TextView resultCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seedJobs();
        searchInput = findViewById(R.id.searchInput);
        categorySpinner = findViewById(R.id.categorySpinner);
        resultCount = findViewById(R.id.resultCount);
        ListView listView = findViewById(R.id.jobList);

        shownJobs.addAll(allJobs);
        adapter = new JobAdapter(this, shownJobs);
        listView.setAdapter(adapter);

        String[] categories = {"Semua Kategori", "IT", "Administrasi", "Keuangan", "Marketing", "Pendidikan"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, categories);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(spinnerAdapter);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterJobs(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                filterJobs();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        listView.setOnItemClickListener((parent, view, position, id) -> showJobDetail(shownJobs.get(position)));
        findViewById(R.id.clearButton).setOnClickListener(v -> {
            searchInput.setText("");
            categorySpinner.setSelection(0);
        });

        findViewById(R.id.aboutButton).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Tentang LokerKu")
                        .setMessage("LokerKu adalah aplikasi contoh pencarian lowongan kerja. Data lowongan pada versi ini merupakan data simulasi/offline.")
                        .setPositiveButton("Tutup", null)
                        .show());
        updateCount();
    }

    private void seedJobs() {
        allJobs.add(new Job("Android Developer", "PT Teknologi Nusantara", "Medan", "IT",
                "Rp5.000.000 - Rp8.000.000", "Full Time",
                "Mengembangkan dan memelihara aplikasi Android serta bekerja sama dengan tim produk.",
                "Minimal D3/S1 Informatika; memahami Java atau Kotlin; memiliki portofolio aplikasi."));
        allJobs.add(new Job("Staff Administrasi", "CV Sukses Bersama", "Pematangsiantar", "Administrasi",
                "Rp2.800.000 - Rp3.500.000", "Full Time",
                "Mengelola dokumen, membuat laporan, dan membantu kegiatan administrasi kantor.",
                "Minimal SMA/SMK; mampu mengoperasikan Microsoft Office; teliti dan komunikatif."));
        allJobs.add(new Job("UI/UX Designer", "Kreatif Digital", "Medan", "IT",
                "Rp4.000.000 - Rp6.500.000", "Full Time",
                "Merancang antarmuka aplikasi dan melakukan evaluasi pengalaman pengguna.",
                "Menguasai Figma; memahami prinsip UI/UX; menyertakan portofolio desain."));
        allJobs.add(new Job("Staff Keuangan", "PT Maju Makmur", "Pematangsiantar", "Keuangan",
                "Rp3.200.000 - Rp4.500.000", "Full Time",
                "Mencatat transaksi, memeriksa bukti pembayaran, dan menyusun laporan keuangan.",
                "Minimal D3 Akuntansi/Keuangan; memahami Excel; jujur dan teliti."));
        allJobs.add(new Job("Digital Marketing", "Media Kreatif ID", "Medan", "Marketing",
                "Rp3.500.000 - Rp5.000.000", "Contract",
                "Mengelola media sosial, membuat konten promosi, dan menganalisis performa kampanye.",
                "Memahami media sosial dan pemasaran digital; kreatif; mampu bekerja dengan target."));
        allJobs.add(new Job("Guru Komputer", "Lembaga Pendidikan Cerdas", "Tebing Tinggi", "Pendidikan",
                "Rp2.500.000 - Rp4.000.000", "Part Time",
                "Mengajar dasar komputer dan membimbing praktik siswa.",
                "Minimal D3; menguasai aplikasi perkantoran; mampu berkomunikasi dengan baik."));
    }

    private void filterJobs() {
        if (adapter == null) return;
        String keyword = searchInput.getText().toString().trim().toLowerCase(Locale.ROOT);
        String category = categorySpinner.getSelectedItem() == null ? "Semua Kategori"
                : categorySpinner.getSelectedItem().toString();

        shownJobs.clear();
        for (Job job : allJobs) {
            boolean matchesText = job.title.toLowerCase(Locale.ROOT).contains(keyword)
                    || job.company.toLowerCase(Locale.ROOT).contains(keyword)
                    || job.location.toLowerCase(Locale.ROOT).contains(keyword);
            boolean matchesCategory = category.equals("Semua Kategori") || job.category.equals(category);
            if (matchesText && matchesCategory) shownJobs.add(job);
        }
        adapter.notifyDataSetChanged();
        updateCount();
    }

    private void updateCount() {
        resultCount.setText(shownJobs.size() + " lowongan ditemukan");
    }

    private void showJobDetail(Job job) {
        String details = "Perusahaan: " + job.company
                + "\nLokasi: " + job.location
                + "\nKategori: " + job.category
                + "\nTipe: " + job.type
                + "\nGaji: " + job.salary
                + "\n\nDESKRIPSI PEKERJAAN\n" + job.description
                + "\n\nPERSYARATAN\n" + job.requirements;
        new AlertDialog.Builder(this)
                .setTitle(job.title)
                .setMessage(details)
                .setNegativeButton("Tutup", null)
                .setPositiveButton("Bagikan Lowongan", (dialog, which) -> {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT, job.title + " - " + job.company
                            + "\nLokasi: " + job.location + "\n" + job.description);
                    startActivity(Intent.createChooser(share, "Bagikan melalui"));
                })
                .show();
    }
}
