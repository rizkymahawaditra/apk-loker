package com.example.lowongan;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

public class JobAdapter extends BaseAdapter {
    private final Context context;
    private final List<Job> jobs;

    public JobAdapter(Context context, List<Job> jobs) {
        this.context = context;
        this.jobs = jobs;
    }

    @Override public int getCount() { return jobs.size(); }
    @Override public Object getItem(int position) { return jobs.get(position); }
    @Override public long getItemId(int position) { return position; }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(context);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        Job job = jobs.get(position);
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 16, 18, 16);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(22);
        bg.setStroke(1, Color.rgb(225, 232, 240));
        card.setBackground(bg);

        TextView title = text(job.title, 18, Color.rgb(25, 48, 78), true);
        TextView company = text(job.company, 14, Color.rgb(74, 91, 112), false);
        TextView location = text("📍 " + job.location + "   •   " + job.type, 12,
                Color.rgb(90, 105, 125), false);
        TextView salary = text(job.salary, 14, Color.rgb(20, 130, 92), true);
        TextView category = text(job.category.toUpperCase(), 10, Color.rgb(34, 100, 170), true);
        category.setPadding(0, 7, 0, 4);

        card.addView(category);
        card.addView(title);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 5;
        card.addView(company, p);
        p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 9;
        card.addView(location, p);
        p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 8;
        card.addView(salary, p);
        return card;
    }
}
