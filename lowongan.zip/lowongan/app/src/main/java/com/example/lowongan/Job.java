package com.example.lowongan;

public class Job {
    public final String title, company, location, category, salary, type, description, requirements;

    public Job(String title, String company, String location, String category,
               String salary, String type, String description, String requirements) {
        this.title = title;
        this.company = company;
        this.location = location;
        this.category = category;
        this.salary = salary;
        this.type = type;
        this.description = description;
        this.requirements = requirements;
    }
}
